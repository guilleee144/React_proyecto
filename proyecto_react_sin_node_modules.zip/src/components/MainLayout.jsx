import React from 'react';
import '../styles/MainLayout.css';

import Sidebar from './Sidebar';
import ProductList from './ProductList';

const MainLayout = () => {
  return (
    <div className="main-layout" style={{ display: 'flex' }}>
      <Sidebar />
      <div style={{ flex: 1, padding: '1rem' }}>
        <ProductList />
      </div>
    </div>
  );
};

export default MainLayout;
