import React, { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { CartContext } from "../context/CartContext";
import "../styles/PaymentForm.css";

const PaymentForm = () => {
  const navigate = useNavigate();
  const { clearCart } = useContext(CartContext); // ✅ Asegurar que obtenemos `clearCart` del contexto

  const [paymentMethod, setPaymentMethod] = useState("credit-card");
  const [formData, setFormData] = useState({
    cardName: "",
    cardNumber: "",
    cvv: "",
    expirationDate: "",
    address: "",
    phone: "",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    clearCart(); // ✅ Ahora se llamará sin errores
    navigate("/payment-confirmation", { state: { paymentMethod, formData } });
  };

  return (
    <div className="payment-page">
      <div className="payment-container">
        <h2>Formulario de Pago</h2>
        <form onSubmit={handleSubmit}>
          <div className="section">
            <label>Método de Pago:</label>
            <select value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)}>
              <option value="credit-card">Tarjeta de Crédito/Débito</option>
              <option value="paypal">PayPal</option>
              <option value="bank-transfer">Transferencia Bancaria</option>
            </select>
          </div>

          {paymentMethod === "credit-card" && (
            <div className="section">
              <label>Titular de la Tarjeta:</label>
              <input type="text" name="cardName" onChange={handleChange} required />
              <label>Número de Tarjeta:</label>
              <input type="text" name="cardNumber" onChange={handleChange} required />
              <label>CVV:</label>
              <input type="text" name="cvv" onChange={handleChange} required />
              <label>Fecha de Caducidad:</label>
              <input type="month" name="expirationDate" onChange={handleChange} required />
            </div>
          )}

          <div className="section">
            <label>Dirección de Envío:</label>
            <input type="text" name="address" onChange={handleChange} required />
            <label>Número de Teléfono:</label>
            <input type="text" name="phone" onChange={handleChange} required />
          </div>

          <button type="submit" className="pay-button">Finalizar Pago</button>
        </form>
      </div>
    </div>
  );
};

export default PaymentForm;
