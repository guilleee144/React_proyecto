import React, { useEffect, useState, useContext } from "react";
import { useParams } from "react-router-dom";
import { CartContext } from "../context/CartContext";
import "../styles/ProductDetail.css";

const ProductDetail = () => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const { addToCart } = useContext(CartContext);

  useEffect(() => {
    fetch("/tienda.json")
      .then((response) => response.json())
      .then((data) => {
        let foundProduct = null;
        Object.entries(data.FIGURAS.Anime).forEach(([anime, items]) => {
          Object.entries(items).forEach(([productName, details]) => {
            if (productName === id) {
              foundProduct = {
                name: productName,
                price: details.precio,
                stock: details.stock,
                images: [details.imagen, details.imagen2, details.imagen3],
                image: details.imagen, // 👈 Aseguramos que `image` sea la principal
                anime: anime,
              };
            }
          });
        });
        setProduct(foundProduct);
      })
      .catch((error) => console.error("Error al cargar los productos:", error));
  }, [id]);

  if (!product) {
    return <p className="loading">Cargando detalles del producto...</p>;
  }

  return (
    <div className="product-container">
      <div className="product-title">{product.name}</div>
      <div className="image-container">
        <img className="product-image" src={product.image} alt={product.name} />
      </div>
      <div className="product-thumbnails">
        {product.images.map((img, index) => (
          <img
            key={index}
            src={img}
            alt={`Thumbnail ${index + 1}`}
            onClick={() => (document.querySelector(".product-image").src = img)}
          />
        ))}
      </div>
      <p className="price">Precio: {product.price} €</p>
      <button className="add-to-cart" onClick={() => addToCart(product)}>
        Añadir al carrito
      </button>
    </div>
  );
};

export default ProductDetail;
