import React from "react";
import { Link } from "react-router-dom";
import "../styles/ProductCard.css";

const ProductCard = ({ product }) => {
  return (
    <Link to={`/product/${product.name}`} className="card-link">
      <div className="card">
        <img src={product.image} alt={product.name} />
        <h2>{product.name}</h2>
        <p className="price">{product.price} €</p>
      </div>
    </Link>
  );
};

export default ProductCard;
