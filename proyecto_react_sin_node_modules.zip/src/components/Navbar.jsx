import React, { useContext } from "react";
import { Link } from "react-router-dom";
import { CartContext } from "../context/CartContext";
import { FaShoppingCart } from "react-icons/fa"; // Importamos el icono de carrito
import "../styles/Navbar.css";

const Navbar = () => {
  const { cart } = useContext(CartContext);
  const totalItems = cart.reduce((sum, p) => sum + p.quantity, 0);

  return (
    <nav className="navbar">
      <div className="logo">Unique Artifacts </div>
      <div className="nav-links">
        <Link to="/">Inicio</Link>
        <Link to="/cart" className="cart-icon">
          <FaShoppingCart size={24} />
          {totalItems > 0 && <span className="cart-badge">{totalItems}</span>}
        </Link>
      </div>
    </nav>
  );
};

export default Navbar;
