import React from "react";
import { useLocation, useNavigate } from "react-router-dom";
import "../styles/PaymentConfirmation.css";

const PaymentConfirmation = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { paymentMethod, formData } = location.state || {};

  return (
    <div className="confirmation-page">
      <div className="confirmation-container">
        <h2>Confirmación de Pago</h2>
        
        <div className="section">
          <strong>Método de Pago:</strong>
          <p>{paymentMethod === "credit-card" ? "Tarjeta de Crédito/Débito" : paymentMethod}</p>
        </div>

        {paymentMethod === "credit-card" && (
          <div className="section">
            <strong>Datos de la Tarjeta:</strong>
            <p>Titular: {formData.cardName}</p>
            <p>Número de Tarjeta: **** **** **** {formData.cardNumber.slice(-4)}</p>
            <p>CVV: ***</p>
            <p>Fecha de Caducidad: {formData.expirationDate}</p>
          </div>
        )}

        <div className="section">
          <strong>Datos de Envío:</strong>
          <p>Dirección: {formData.address}</p>
          <p>Teléfono: {formData.phone}</p>
        </div>

        <button className="return-button" onClick={() => navigate("/")}>
          Volver al menú
        </button>
      </div>
    </div>
  );
};

export default PaymentConfirmation;
