import React from "react";
import { useNavigate } from "react-router-dom";
import "../styles/Sidebar.css";

const Sidebar = ({ onFilter }) => {
  const navigate = useNavigate();

  const handleFilterClick = (category) => {
    navigate("/"); // ✅ Redirigir siempre a productos antes de filtrar
    onFilter(category);
  };

  return (
    <div className="sidebar">
      <h2>SHOPPING</h2>
      <ul>
        <li onClick={() => handleFilterClick("Todos")}>Todos</li>
        <li onClick={() => handleFilterClick("Dragon Ball")}>Dragon Ball</li>
        <li onClick={() => handleFilterClick("Jujutsu Kaisen")}>Jujutsu Kaisen</li>
        <li onClick={() => handleFilterClick("One Piece")}>One Piece</li>
        <li onClick={() => handleFilterClick("Bleach")}>Bleach</li>
        <li onClick={() => handleFilterClick("Attack on Titan")}>Attack on Titan</li>
        <li onClick={() => handleFilterClick("Hunter x Hunter")}>Hunter x Hunter</li>
        <li onClick={() => handleFilterClick("Saint Seiya")}>Saint Seiya</li>
        <li onClick={() => handleFilterClick("Blue Lock")}>Blue Lock</li>
        <li onClick={() => handleFilterClick("Evangelion")}>Evangelion</li>
        <li onClick={() => handleFilterClick("Tokyo Ghoul")}>Tokyo Ghoul</li>
        <li onClick={() => handleFilterClick("Chainsaw Man")}>Chainsaw Man</li>
        <li onClick={() => handleFilterClick("Demon Slayer")}>Demon Slayer</li>
        <li onClick={() => handleFilterClick("My Hero Academia")}>My Hero Academia</li>
        <li onClick={() => handleFilterClick("Fairy Tail")}>Fairy Tail</li>
      </ul>
    </div>
  );
};

export default Sidebar;
