import React, { useContext } from "react";
import { CartContext } from "../context/CartContext";
import { useNavigate } from "react-router-dom";
import "../styles/Cart.css";

const Cart = () => {
  const { cart, removeFromCart } = useContext(CartContext);
  const navigate = useNavigate(); // Para redirigir a la página de pago

  return (
    <div className="cart-page">
      <div className="cart-container">
        <h2>Tu Carrito</h2>
        {cart.length === 0 ? (
          <p>El carrito está vacío.</p>
        ) : (
          <>
            {cart.map((product, index) => (
              <div key={index} className="cart-item">
                <img src={product.image} alt={product.name} className="cart-image" />
                <div>
                  <h3>{product.name}</h3>
                  <p>Precio: {product.price} €</p>
                  <p>Cantidad: {product.quantity}</p>
                </div>
                <button onClick={() => removeFromCart(product.name)}>Eliminar</button>
              </div>
            ))}
            <button className="checkout-button" onClick={() => navigate("/payment")}>
              Proceder al pago
            </button>
          </>
        )}
      </div>
    </div>
  );
};

export default Cart;
