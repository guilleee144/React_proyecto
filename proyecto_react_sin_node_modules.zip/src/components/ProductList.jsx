import React, { useState, useEffect } from "react";
import ProductCard from "./ProductCard";
import "../styles/ProductList.css";

const ProductList = ({ selectedAnime }) => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetch("/tienda.json")
      .then((response) => response.json())
      .then((data) => {
        console.log("Datos JSON cargados:", data); // 👈 Verifica en consola
  
        const formattedProducts = [];
        Object.entries(data.FIGURAS.Anime).forEach(([anime, items]) => {
          Object.entries(items).forEach(([productName, details]) => {
            formattedProducts.push({
              name: productName,
              price: details.precio,
              stock: details.stock,
              image: details.imagen || details.imagen1, // 👈 Asegura que tome la clave correcta
              anime: anime,
            });
          });
        });
  
        console.log("Productos procesados con imágenes:", formattedProducts); // 👈 Verifica en consola
        setProducts(formattedProducts);
      })
      .catch((error) => console.error("Error al cargar los productos:", error));
  }, []);  
  

  const filteredProducts =
    selectedAnime === "Todos"
      ? products
      : products.filter((p) => p.anime === selectedAnime);

  return (
    <div className="product-list">
      {filteredProducts.length > 0 ? (
        filteredProducts.map((product, index) => (
          <ProductCard key={index} product={product} />
        ))
      ) : (
        <p className="no-results">No hay productos disponibles</p>
      )}
    </div>
  );
};

export default ProductList;
