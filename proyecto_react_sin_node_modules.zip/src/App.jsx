import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Sidebar from "./components/Sidebar";
import ProductList from "./components/ProductList";
import ProductDetail from "./components/ProductDetail";
import Cart from "./components/Cart";
import PaymentForm from "./components/PaymentForm";
import PaymentConfirmation from "./components/PaymentConfirmation";
import { CartProvider } from "./context/CartContext";
import "./styles/App.css";

function App() {
  const [selectedAnime, setSelectedAnime] = useState("Todos");

  return (
    <CartProvider>
      <Router>
        <div className="app-container">
          <Navbar />
          <div className="content">
            <Sidebar onFilter={setSelectedAnime} />
            <div className="main-content">
              <Routes>
                <Route path="/" element={<ProductList selectedAnime={selectedAnime} />} />
                <Route path="/product/:id" element={<ProductDetail />} />
                <Route path="/cart" element={<Cart />} />
                <Route path="/payment" element={<PaymentForm />} /> {/* Página de pago */}
                <Route path="/payment-confirmation" element={<PaymentConfirmation />} /> {/* Confirmación de pago */}
              </Routes>
            </div>
          </div>
        </div>
      </Router>
    </CartProvider>
  );
}

export default App;
