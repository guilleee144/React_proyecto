export function flattenProducts(data) {
    const products = [];
    if (data.FIGURAS) {
      const mainCategories = data.FIGURAS;
      // mainCat: "Anime", "My Hero Academia", etc.
      for (const mainCat in mainCategories) {
        const mainValue = mainCategories[mainCat];
        // Si el primer elemento tiene la propiedad "precio", significa que son productos directos
        const firstKey = Object.keys(mainValue)[0];
        if (mainValue[firstKey] && mainValue[firstKey].precio !== undefined) {
          // mainValue son productos directos
          for (const productName in mainValue) {
            const details = mainValue[productName];
            products.push({
              id: `${mainCat}-${productName}`,
              title: productName,
              ...details,
              category: mainCat,
              subcategory: null
            });
          }
        } else {
          // mainValue contiene subcategorías
          for (const subCat in mainValue) {
            const subCatProducts = mainValue[subCat];
            for (const productName in subCatProducts) {
              const details = subCatProducts[productName];
              products.push({
                id: `${mainCat}-${subCat}-${productName}`,
                title: productName,
                ...details,
                category: mainCat,
                subcategory: subCat
              });
            }
          }
        }
      }
    }
    return products;
  }
  